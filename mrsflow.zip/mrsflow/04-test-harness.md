# 04 — Test Harness

## The oracle

Microsoft's M implementation is the reference. Any divergence is, by default, a bug in mrsflow. The user's existing query corpus is both the test suite and the spec for what v1 must support.

## How to run Microsoft's M headlessly

Two viable paths:

1. **Excel via COM automation / PowerShell.** Open workbook, refresh queries, export to Parquet (or CSV → Arrow → Parquet). Slow but works.
2. **PowerQueryNet** ([github.com/gsimardnet/PowerQueryNet](https://github.com/gsimardnet/PowerQueryNet)) — a .NET wrapper around the Mashup Engine. Requires Power BI Desktop or the Power Query SDK installed. Faster than Excel automation, still Windows-only.

Either way: a small harness runs each test query through Microsoft's runtime, captures the result as Arrow/Parquet, and stashes it as a "golden" output for that query.

## The diff

Output comparison happens at the Arrow level, not the text level. The `arrow` crate has comparison kernels that handle:
- Schema equality (column names, types, nullability)
- Per-column value equality with proper null semantics
- Approximate float comparison if needed

This sidesteps the entire text-format ambiguity around dates, floats, locale-formatted numbers, etc.

## Test cycle

```
for query in corpus:
    expected = run_microsoft_m(query)        # produces Parquet
    actual   = run_mrsflow(query)            # produces Parquet
    assert arrow_equals(expected, actual)
```

Failed tests show:
- Schema diff (which columns differ in type/name/nullability)
- First N differing rows
- Optionally: which step in the M expression introduced the divergence (harder, deferred)

## Regression tracking

Every fixed bug becomes a new test case. Every query the user adds to their real workload gets dropped into the corpus. The corpus grows monotonically; v1 ships when 100% of it passes.

## What this catches and what it doesn't

**Catches:**
- Wrong arithmetic, wrong comparison semantics, wrong type coercions
- Sort stability differences
- Null handling divergences
- Group-by aggregation differences
- Join semantics (inner vs left vs outer, key matching)
- Off-by-one errors in any list/table operation

**Doesn't catch:**
- Performance regressions (separate benchmarking needed; not v1 priority)
- Memory leaks under sustained load (separate concern)
- WASM-specific behaviour differences (the WASM build needs its own smoke tests)
- Anything where mrsflow produces "the right answer" but in a different way than Microsoft's (spec-correct but oracle-different — judgment call when this happens)

## Refining the parser specifically

Microsoft's TypeScript parser ([github.com/microsoft/powerquery-parser](https://github.com/microsoft/powerquery-parser)) can be used as a parser-level oracle independently. Run a corpus of M source files through both parsers, compare ASTs structurally. This catches parsing bugs without needing to evaluate anything. Worth doing for the parser layer specifically because parser bugs cascade into evaluation bugs that look mysterious.
